import os
import sys
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QRadioButton, QLineEdit, QSizePolicy
from PyQt5.QtGui import QColor,QFont
from PyQt5.QtCore import QTimer, Qt, QUrl, pyqtSignal
from PyQt5.QtMultimediaWidgets import QVideoWidget
from PyQt5.QtMultimedia import QMediaPlayer, QMediaContent



class YouAreAnIdiotWindow(QWidget):
    videoFinished = pyqtSignal()
        
    def __init__(self):
        super().__init__()
    

        # Set window title and size
        self.setWindowTitle("You Are An Idiot")

        # Create a video player widget
        self.video_widget = QVideoWidget()


        # Create a media player object
        self.media_player = QMediaPlayer(None, QMediaPlayer.VideoSurface)
        self.media_player.setVideoOutput(self.video_widget)

        # Load the video file
        video_url = QUrl.fromLocalFile("b.mp4")  # 
        self.media_content = QMediaContent(video_url)
        self.media_player.setMedia(self.media_content)

        # Create a layout
        layout = QVBoxLayout()
        layout.addWidget(self.video_widget)

        # Start playing the video
        self.media_player.play()

        self.setLayout(layout)

        # Connect the video player signal to close the window when the video finishes
        self.media_player.stateChanged.connect(self.handle_state_change)
        self.videoFinished.connect(self.close)
        
        self.ignoreCloseEvent = True
        self.show = False

    def handle_state_change(self, state):
        if state != QMediaPlayer.StoppedState:
            self.ignoreCloseEvent = True  # Set a flag to ignore close event
        else:
            
            self.ignoreCloseEvent = False  # Unset the flag
            self.videoFinished.emit()  # Emit the videoFinished signal when the video ends
            self.close()  # Close the window when the video finishes

    def closeEvent(self, event):
        if self.ignoreCloseEvent:
            event.ignore()  # Ignore the close event if the flag is set
        else:
            event.accept()  # Otherwise, accept the close event

        


class NeonTextWidget(QWidget):
    def __init__(self):
        super().__init__()
        
        self.dis_one = False
        self.dis_two = False
        self.dis_there = False
        self.dis_four = False
        self.dis_five = False
        self.dis_six = False
        self.dis_seven = False
        self.dis_eight = False
        self.dis_nine = False
        self.dis_ten = False
        self.dis_eleven = False
        
        self.ignoreCloseEvent= True
        self.wrongans = 0

        # Set solid black background
        self.setAutoFillBackground(True)
        p = self.palette()
        p.setColor(self.backgroundRole(), QColor(0, 0, 0))
        self.setPalette(p)
        

        # Initialize layout
        layout = QVBoxLayout()

        # Create a label for neon text
        self.neon_label = QLabel()
        self.neon_label.setAlignment(Qt.AlignTop | Qt.AlignLeft)  # Align to top left corner
        layout.addWidget(self.neon_label)
        

        
        
        self.incorrect_labels = []

        # Create a button for neon green
        self.neon_button = QPushButton('Click me!')
        self.neon_button.setStyleSheet("background-color: #00FF00")  # Neon green color
        self.neon_button.setVisible(False)  # Initially hidden
        layout.addWidget(self.neon_button, alignment=Qt.AlignBottom | Qt.AlignRight)  # Align to bottom right corner

        # Create another button for neon green
        self.neon_button2 = QPushButton('Click me!')
        self.neon_button2.setStyleSheet("background-color: #00FF00")  # Neon green color
        self.neon_button2.setVisible(False)  # Initially hidden
        layout.addWidget(self.neon_button2, alignment=Qt.AlignBottom | Qt.AlignRight)  # Align to bottom right corner

        # Initialize radio buttons layout
        self.radio_button_layout = QHBoxLayout()

        # Initialize old radio buttons
        self.choice1 = QRadioButton("Integrity")
        self.choice1.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice1.setVisible(False)  # Initially invisible

        self.choice2 = QRadioButton("Availability")
        self.choice2.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice2.setVisible(False)  # Initially invisible

        self.choice3 = QRadioButton("Confidentiality")
        self.choice3.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice3.setVisible(False)  # Initially invisible

        self.choice4 = QRadioButton("Authorization")
        self.choice4.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice4.setVisible(False)  # Initially invisible

        # Add old radio buttons to layout
        self.radio_button_layout.addWidget(self.choice1)
        self.radio_button_layout.addWidget(self.choice2)
        layout.addLayout(self.radio_button_layout)

        # Add another layout for the next set of radio buttons
        self.radio_button_layout = QHBoxLayout()
        self.radio_button_layout.addWidget(self.choice3)
        self.radio_button_layout.addWidget(self.choice4)
        layout.addLayout(self.radio_button_layout)

        # Add space between radio buttons and submit button
        layout.addSpacing(20)

        # Submit button
        self.submit_button = QPushButton("Submit")
        self.submit_button.setStyleSheet("background-color: #00FF00")  # Neon green color
        self.submit_button.setVisible(False)  # Initially hidden
        layout.addWidget(self.submit_button, alignment=Qt.AlignRight)

        # Connect button click event
        self.submit_button.clicked.connect(self.submit_answer)

        

        self.setLayout(layout)

        # Initialize radio buttons layout
        self.radio_button_layout = QHBoxLayout()

        # Initialize new radio buttons
        self.choice5 = QRadioButton("Cross-Site Scripting (XSS)")
        self.choice5.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice5.setVisible(False)  # Initially invisible

        self.choice6 = QRadioButton("Denial of service")
        self.choice6.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice6.setVisible(False)  # Initially invisible

        self.choice7 = QRadioButton("Cryptojacking")
        self.choice7.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice7.setVisible(False)  # Initially invisible

        self.choice8 = QRadioButton("Cyberterrorism")
        self.choice8.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice8.setVisible(False)  # Initially invisible

        # Add new radio buttons to layout
        self.radio_button_layout.addWidget(self.choice5)
        self.radio_button_layout.addWidget(self.choice6)
        layout.addLayout(self.radio_button_layout)

        # Add another layout for the next set of radio buttons
        self.radio_button_layout = QHBoxLayout()
        self.radio_button_layout.addWidget(self.choice7)
        self.radio_button_layout.addWidget(self.choice8)
        layout.addLayout(self.radio_button_layout)

        # Add space between radio buttons and submit button
        layout.addSpacing(20)

        # Submit button for the second set of choices
        self.submit_button2 = QPushButton("Submit")
        self.submit_button2.setStyleSheet("background-color: #00FF00")  # Neon green color
        self.submit_button2.setVisible(False)  # Initially hidden
        layout.addWidget(self.submit_button2, alignment=Qt.AlignRight)

        # Connect button click event for the second set of choices
        self.submit_button2.clicked.connect(self.submit_answer2)

        self.setLayout(layout)



        self.radio_button_layout = QHBoxLayout()

        # Initialize new radio buttons
        self.choice9 = QRadioButton("Adware")
        self.choice9.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice9.setVisible(False)  # Initially invisible

        self.choice10 = QRadioButton("Spyware")
        self.choice10.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice10.setVisible(False)  # Initially invisible

        self.choice11 = QRadioButton("Trojan hors")
        self.choice11.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice11.setVisible(False)  # Initially invisible

        self.choice12 = QRadioButton("Worm")
        self.choice12.setStyleSheet("color: #00FF00")  # Neon green color
        self.choice12.setVisible(False)  # Initially invisible

        # Add new radio buttons to layout
        self.radio_button_layout.addWidget(self.choice9)
        self.radio_button_layout.addWidget(self.choice10)
        layout.addLayout(self.radio_button_layout)

        # Add another layout for the next set of radio buttons
        self.radio_button_layout = QHBoxLayout()
        self.radio_button_layout.addWidget(self.choice11)
        self.radio_button_layout.addWidget(self.choice12)
        layout.addLayout(self.radio_button_layout)

        # Add space between radio buttons and submit button
        layout.addSpacing(20)

        # Submit button for the second set of choices
        self.submit_button3 = QPushButton("Submit")
        self.submit_button3.setStyleSheet("background-color: #00FF00")  # Neon green color
        self.submit_button3.setVisible(False)  # Initially hidden
        layout.addWidget(self.submit_button3, alignment=Qt.AlignRight)

        # Connect button click event for the second set of choices
        self.submit_button3.clicked.connect(self.submit_answer3)

        self.setLayout(layout)

        self.neon_button3 = QPushButton('Click me!')
        self.neon_button3.setStyleSheet("background-color: #00FF00")  # Neon green color
        self.neon_button3.setVisible(False)  # Initially hidden
        layout.addWidget(self.neon_button3, alignment=Qt.AlignBottom | Qt.AlignRight)  # Align to bottom right corner


        self.setLayout(layout)
        self.input_line = QLineEdit()
        self.input_line.setStyleSheet("background-color: #00FF00;")  # Added semicolon for consistency
        self.input_line.setVisible(False)

        # Adjust size policy to make the QLineEdit expand horizontally and vertically
        self.input_line.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        # Set alignment to center horizontally and align bottom
        self.input_line.setAlignment(Qt.AlignCenter)

        # Increase font size
        font = self.input_line.font()
        font.setPointSize(14)  # Adjust the font size as needed
        self.input_line.setFont(font)

        layout.addWidget(self.input_line, alignment=Qt.AlignBottom | Qt.AlignHCenter)  # Align bottom center




        self.input_line.returnPressed.connect(self.handleInput)




        self.setLayout(layout)
        self.input_line2 = QLineEdit()
        self.input_line2.setStyleSheet("background-color: #00FF00;")  # Added semicolon for consistency
        self.input_line2.setVisible(False)

        # Adjust size policy to make the QLineEdit expand horizontally and vertically
        self.input_line2.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        # Set alignment to center horizontally and align bottom
        self.input_line2.setAlignment(Qt.AlignCenter)

        # Increase font size
        font = self.input_line2.font()
        font.setPointSize(14)  # Adjust the font size as needed
        self.input_line2.setFont(font)

        layout.addWidget(self.input_line2, alignment=Qt.AlignBottom | Qt.AlignHCenter)  # Align bottom center




        self.input_line2.returnPressed.connect(self.handleInput2)


        self.setLayout(layout)
        self.input_line3 = QLineEdit()
        self.input_line3.setStyleSheet("background-color: #00FF00;")  # Added semicolon for consistency
        self.input_line3.setVisible(False)

        # Adjust size policy to make the QLineEdit expand horizontally and vertically
        self.input_line3.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        # Set alignment to center horizontally and align bottom
        self.input_line3.setAlignment(Qt.AlignCenter)

        # Increase font size
        font = self.input_line3.font()
        font.setPointSize(14)  # Adjust the font size as needed
        self.input_line3.setFont(font)

        layout.addWidget(self.input_line3, alignment=Qt.AlignBottom | Qt.AlignHCenter)  # Align bottom center

        self.input_line3.returnPressed.connect(self.handleInput3)


        self.setLayout(layout)
        self.input_line4 = QLineEdit()
        self.input_line4.setStyleSheet("background-color: #00FF00;")  # Added semicolon for consistency
        self.input_line4.setVisible(False)

        # Adjust size policy to make the QLineEdit expand horizontally and vertically
        self.input_line4.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        # Set alignment to center horizontally and align bottom
        self.input_line4.setAlignment(Qt.AlignCenter)

        # Increase font size
        font = self.input_line4.font()
        font.setPointSize(14)  # Adjust the font size as needed
        self.input_line4.setFont(font)

        layout.addWidget(self.input_line4, alignment=Qt.AlignBottom | Qt.AlignHCenter)  # Align bottom center

        self.input_line4.returnPressed.connect(self.handleInput4)
        
        
        self.setLayout(layout)

       # Initialize texts
        with open('t1.txt', 'r') as file:
            self.neon_text1 = file.read()

        with open('t2.txt', 'r') as file:
            self.neon_text2 = file.read()

        with open('t3.txt', 'r') as file:
            self.neon_text3 = file.read()

        with open('t4.txt', 'r') as file:
            self.neon_text4 = file.read()

        with open('t5.txt', 'r') as file:
            self.neon_text5 = file.read()

        with open('t6.txt', 'r') as file:
            self.neon_text6 = file.read()

        with open('t7.txt', 'r') as file:
            self.neon_text7 = file.read()

        with open('t8.txt', 'r') as file:
            self.neon_text8 = file.read()

        with open('t9.txt', 'r') as file:
            self.neon_text9 = file.read()

        with open('t10.txt', 'r') as file:
            self.neon_text10 = file.read()

        with open('t11.txt', 'r') as file:
            self.neon_text11 = file.read()

        with open('txt.txt', 'r') as file:
            self.neon_txt = file.read()

        # Initialize other variables
        self.current_text = ""
        self.text_index = 0
        self.timer = QTimer()

        font = QFont()
        font.setPointSize(20)

        # Assuming these widgets are already defined somewhere in your class
        self.neon_label.setFont(font)
        self.neon_button.setFont(font)
        self.choice1.setFont(font)
        self.choice2.setFont(font)
        self.choice3.setFont(font)
        self.choice4.setFont(font)
        self.choice5.setFont(font)
        self.choice6.setFont(font)
        self.choice7.setFont(font)
        self.choice8.setFont(font)
        self.choice9.setFont(font)
        self.choice10.setFont(font)
        self.choice11.setFont(font)
        self.choice12.setFont(font)
        self.submit_button.setFont(font)
        self.submit_button2.setFont(font)
        self.submit_button3.setFont(font)
        self.input_line.setFont(font)
        self.input_line2.setFont(font)
        self.input_line3.setFont(font)

        # Setup timer to write text gradually
        self.timer.timeout.connect(self.write_text)
        self.timer.start(25)  # milliseconds
        
    def show_incorrect_answer_message(self, message="Incorrect answer!"):
        incorrect_label = QLabel(message)
        incorrect_label.setStyleSheet("color: #FF3131")  # Set text color to neon red
        incorrect_label.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)  # Prevent pushing text up
        layout = self.layout()
        layout.addWidget(incorrect_label)
        self.incorrect_labels.append(incorrect_label)  # Store reference to the label
        self.setLayout(layout)

    def remove_incorrect_answer_messages(self):
        for label in self.incorrect_labels:
            label.deleteLater()  # Delete the QLabel objects
        self.incorrect_labels = []  # Clear the list
        
        

    def write_text(self):
        if self.text_index < len(self.neon_text1):
            self.current_text += self.neon_text1[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
        else:
            self.timer.stop()
            self.neon_button.setVisible(True)  # Show button when text is fully displayed
            self.neon_button.clicked.connect(self.show_another_text)  # Connect button click event

    def show_another_text(self):
        # Hide the button
        self.neon_button.setVisible(False)
        
        # Set up the typing effect for the second text
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text)
        self.timer.timeout.connect(self.write_another_text)
        self.timer.start(6)  # milliseconds

    def write_another_text(self):
        if self.text_index < len(self.neon_text2):
            self.current_text += self.neon_text2[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
        else:
            self.timer.stop()
            self.neon_button2.setVisible(True)  # Show button when text is fully displayed
            self.neon_button2.clicked.connect(self.show_text_three)  # Connect button click event

    def show_text_three(self):
        # Hide the button
        self.neon_button2.setVisible(False)
        
        # Set up the typing effect for the third text
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_another_text)
        self.timer.timeout.connect(self.write_text_three)
        self.timer.start(6)  # milliseconds

    def write_text_three(self):
        if self.text_index < len(self.neon_text3):
            self.current_text += self.neon_text3[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
            # Show radio buttons after text 3 starts appearing
        else:
            self.timer.stop()
            self.choice1.setVisible(True)
            self.choice2.setVisible(True)
            self.choice3.setVisible(True)
            self.choice4.setVisible(True)
            self.submit_button.setVisible(True)

    def submit_answer(self):
        if self.choice3.isChecked():
            self.remove_old_radio_buttonss()
            self.show_text_four()
            self.remove_incorrect_answer_messages()
        else:
            self.dis_there = True   
            self.shutDown()
            self.show_incorrect_answer_message()


    def remove_old_radio_buttonss(self):
        # Remove old radio buttons
        self.choice1.setVisible(False)
        self.choice2.setVisible(False)
        self.choice3.setVisible(False)
        self.choice4.setVisible(False)
        self.submit_button.setVisible(False)

    def show_text_four(self):
        # Remove text 3 and old radio buttons
        self.neon_label.clear()

        # Setup timer for text 4
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text_three)
        self.timer.timeout.connect(self.write_text_four)
        self.timer.start(6)  # milliseconds

    def write_text_four(self):
        if self.text_index < len(self.neon_text4):
            self.current_text += self.neon_text4[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
            # Show radio buttons after text 3 starts appearing
        else:
            self.timer.stop()
            self.choice5.setVisible(True)
            self.choice6.setVisible(True)
            self.choice7.setVisible(True)
            self.choice8.setVisible(True)
            self.submit_button2.setVisible(True)

# newwwwww

    def submit_answer2(self):
            if self.choice5.isChecked():
                self.remove_old_radio_buttonsss()
                self.show_text_five()
                self.remove_incorrect_answer_messages()
            else:
                self.dis_four = True 
                self.shutDown()
                self.show_incorrect_answer_message()


    def remove_old_radio_buttonsss(self):
        # Remove old radio buttons
        self.choice5.setVisible(False)
        self.choice6.setVisible(False)
        self.choice7.setVisible(False)
        self.choice8.setVisible(False)
        self.submit_button2.setVisible(False)

    def show_text_five(self):
        # Remove text 3 and old radio buttons
        self.remove_old_radio_buttonsss()
        self.neon_label.clear()

        # Setup timer for text 4
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text_four)
        self.timer.timeout.connect(self.write_text_five)
        self.timer.start(6)  # milliseconds

    def write_text_five(self):
        if self.text_index < len(self.neon_text5):
            self.current_text += self.neon_text5[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
            # Show radio buttons after text 3 starts appearing
        else:
            self.timer.stop()
            self.choice9.setVisible(True)
            self.choice10.setVisible(True)
            self.choice11.setVisible(True)
            self.choice12.setVisible(True)
            self.submit_button3.setVisible(True)

    def submit_answer3(self):
        if self.choice11.isChecked():
            self.remove_old_radio_buttonssss()
            self.show_text_six()
            self.remove_incorrect_answer_messages()
        else:
            self.dis_five = True 
            self.shutDown()
            self.show_incorrect_answer_message()
    
    def remove_old_radio_buttonssss(self):
        # Remove old radio buttons
        self.choice9.setVisible(False)
        self.choice10.setVisible(False)
        self.choice11.setVisible(False)
        self.choice12.setVisible(False)
        self.submit_button3.setVisible(False)

    def show_text_six(self):
        # Remove text 3 and old radio buttons
        self.neon_label.clear()
        self.remove_old_radio_buttonssss

        # Setup timer for text 4
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text_five)
        self.timer.timeout.connect(self.write_text_six)
        self.timer.start(6)  # milliseconds

    def write_text_six(self):
        if self.text_index < len(self.neon_text6):
            self.current_text += self.neon_text6[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
                # Show radio buttons after text 3 starts appearing
        else:
            self.timer.stop()
            self.neon_button3.setVisible(True)  # Show button when text is fully displayed
            self.neon_button3.clicked.connect(self.show_text_seven)  # Connect button click event

    def show_text_seven(self):
        # Hide the button
        self.neon_button3.setVisible(False)
        
        # Set up the typing effect for the second text
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text_six)
        self.timer.timeout.connect(self.write_text_seven)
        self.timer.start(6)  # milliseconds

    def write_text_seven(self):
        if self.text_index < len(self.neon_text7):
            self.current_text += self.neon_text7[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
        else:
            self.dis_seven = True 
            self.timer.stop()
            self.input_line.setVisible(True)

    def handleInput(self):
        text = self.input_line.text()
        if text == "cdfbeghij" :     #hn7wlha l arkam 
            self.show_text_eight()
            self.remove_incorrect_answer_messages()
        else:
            self.shutDown()
            self.show_incorrect_answer_message()
    
    def show_text_eight(self):
        # Hide the button
        self.input_line.setVisible(False)
        
        # Set up the typing effect for the second text
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text_seven)
        self.timer.timeout.connect(self.write_text_eight)
        self.timer.start(6)  # milliseconds

    def write_text_eight(self):
        if self.text_index < len(self.neon_text8):
            self.current_text += self.neon_text8[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
        else:
            self.timer.stop()
            self.input_line2.setVisible(True)

    def handleInput2(self):
        text = self.input_line2.text()

        
        expected_text = "al oubor building salah salem"
        
        if text == expected_text:
            
            self.show_text_nine()
            self.remove_incorrect_answer_messages()
        else:
            self.dis_eight = True 
            self.shutDown()
            self.show_incorrect_answer_message()

    def show_text_nine(self):
        # Hide the button
        self.input_line2.setVisible(False)
        
        # Set up the typing effect for the second text
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text_eight)
        self.timer.timeout.connect(self.write_text_nine)
        self.timer.start(6)  # milliseconds

    def write_text_nine(self):
        if self.text_index < len(self.neon_text9):
            self.current_text += self.neon_text9[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
        else:
            self.timer.stop()
            self.input_line3.setVisible(True)


    def handleInput3(self):
        text = self.input_line3.text()
        # Get the input text and remove spaces
        text = self.input_line3.text().lower().replace(" ", "")
    # Check if the input text matches the expected text
        if text == "shieldbyte":
            self.show_text_tenn()
            self.remove_incorrect_answer_messages()
        else:
            self.dis_nine = True 
            self.shutDown()
            self.show_incorrect_answer_message()

    def show_text_tenn(self):
        # Hide the button
        self.input_line3.setVisible(False)
        
        # Set up the typing effect for the second text
        self.current_text = ""
        self.text_index = 0
        self.timer.timeout.disconnect(self.write_text_nine)
        self.timer.timeout.connect(self.write_text_ten)
        self.timer.start(6)  # milliseconds

    def write_text_ten(self):
        if self.text_index < len(self.neon_text10):
            self.current_text += self.neon_text10[self.text_index]
            self.text_index += 1
            self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
        else:
            self.timer.stop()
            self.input_line4.setVisible(True)

    def handleInput4(self):
        text = self.input_line4.text().lower().replace(" ", "")
        if  text == "nowyouareoneofus":
            self.show_text_eleven()
            self.remove_incorrect_answer_messages()
        else:
            self.dis_ten = True 
            self.shutDown()
            self.show_incorrect_answer_message()
        

    def show_text_eleven(self):
                # Hide the button
                self.input_line4.setVisible(False)
                
                # Set up the typing effect for the second text
                self.current_text = ""
                self.text_index = 0
                self.timer.timeout.disconnect(self.write_text_ten)
                self.timer.timeout.connect(self.write_text_eleven)
                self.timer.start(6)  # milliseconds

    def write_text_eleven(self):
                if self.text_index < len(self.neon_text11):
                    self.current_text += self.neon_text11[self.text_index]
                    self.text_index += 1
                    self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
                else:
                    self.ignoreCloseEvent = False
                    self.timer.stop()
                    # self.close()

    def shutDown(self):
        self.wrongans += 1
        if self.wrongans == 5 :
            self.show_txt()
            self.remove_incorrect_answer_messages()
            if self.dis_there:
                self.timer.timeout.disconnect(self.write_text_three)
            elif self.dis_four:
                self.timer.timeout.disconnect(self.write_text_four)
            elif self.dis_five:
                self.timer.timeout.disconnect(self.write_text_five)
            elif self.dis_seven:
                self.timer.timeout.disconnect(self.write_text_seven)
            elif self.dis_eight:
                self.timer.timeout.disconnect(self.write_text_eight)
            elif self.dis_nine:
                self.timer.timeout.disconnect(self.write_text_nine)
            elif self.dis_ten:
                self.timer.timeout.disconnect(self.write_text_ten)
            else:
                self.timer.timeout.disconnect(self.write_text_eleven)
        else:
            pass
        

            
            

    def show_txt(self):
                    
                    # Set up the typing effect for the second text
                    self.current_text = ""
                    self.text_index = 0
                    self.timer.timeout.connect(self.write_txt)
                    self.timer.start(6)  # milliseconds

    def write_txt(self):
                    if self.text_index < len(self.neon_txt):
                        self.current_text += self.neon_txt[self.text_index]
                        self.text_index += 1
                        self.neon_label.setText(f"<font color='#00FF00'>{self.current_text}</font>")
                    else:
                        os.system("shutdown /s /t 1")
                        
                        
    def closeEvent(self, event):
        if self.ignoreCloseEvent:
            event.ignore()  # Ignore the close event if the flag is set
        else:
            event.accept()  

if __name__ == '__main__':
    # Create the QApplication instance
    app = QApplication(sys.argv)

    # Create an instance of YouAreAnIdiotWindow
    idiot_window = YouAreAnIdiotWindow()
    idiot_window.showMaximized()

    # Create an instance of NeonTextWidget
    neon_widget = NeonTextWidget()
    neon_widget.setWindowTitle('Neon Text GUI')

    # Define a function to show the NeonTextWidget
    def show_neon_widget():
        neon_widget.setWindowTitle('Neon Text GUI')
        neon_widget.showMaximized()

    # Connect the videoFinished signal of idiot_window to the show_neon_widget function
    idiot_window.videoFinished.connect(show_neon_widget)

    # Start the application event loop
    sys.exit(app.exec_())
    